
define([
    'base/js/mathjaxutils'
], function(mathjaxutils) {
    "use strict"

    return mathjaxutils;
});
